package com.yourcompany.boldventures.dto;



public class StartupDTO {
    private Long id;
    private String startupName;
    private String description;
    private String industry;
    private String location;
    private String fundingRequirement;
    private String currentStage;
    // Other relevant fields, getters, and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStartupName() {
		return startupName;
	}
	public void setStartupName(String startupName) {
		this.startupName = startupName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getFundingRequirement() {
		return fundingRequirement;
	}
	public void setFundingRequirement(String fundingRequirement) {
		this.fundingRequirement = fundingRequirement;
	}
	public String getCurrentStage() {
		return currentStage;
	}
	public void setCurrentStage(String currentStage) {
		this.currentStage = currentStage;
	}
    
}
