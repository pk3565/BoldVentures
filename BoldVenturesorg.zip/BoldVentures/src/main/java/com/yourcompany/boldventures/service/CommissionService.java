package com.yourcompany.boldventures.service;



public class CommissionService {
    public double calculateCommission(double transactionAmount, double commissionPercentage) {
        return transactionAmount * (commissionPercentage / 100);
    }

    public static void main(String[] args) {
        // Example calculation for a transaction of 1 lakh with a 1% commission
        double transactionAmount = 100000; // 1 lakh
        double commissionPercentage = 1; // 1%
        
        CommissionService commissionService = new CommissionService();
        double commissionAmount = commissionService.calculateCommission(transactionAmount, commissionPercentage);
        
        System.out.println("Commission amount for a transaction of 1 lakh with 1% commission: " + commissionAmount);
    }
}
