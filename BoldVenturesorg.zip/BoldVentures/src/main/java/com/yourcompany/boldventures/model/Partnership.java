package com.yourcompany.boldventures.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "interestedPartners")
public class Partnership {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	@Column
    private Long senderUserId;
	@Column
    private Long receiverUserId;
	@Column
    private String message;
	@Column
    private String status;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSenderUserId() {
		return senderUserId;
	}
	public void setSenderUserId(Long senderUserId) {
		this.senderUserId = senderUserId;
	}
	public Long getReceiverUserId() {
		return receiverUserId;
	}
	public void setReceiverUserId(Long receiverUserId) {
		this.receiverUserId = receiverUserId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Partnership(Long id, Long senderUserId, Long receiverUserId, String message, String status) {
		super();
		this.id = id;
		this.senderUserId = senderUserId;
		this.receiverUserId = receiverUserId;
		this.message = message;
		this.status = status;
	}
	public Partnership() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Partnership(Long startupId, Long investorId) {
		return;
		
	}
    
}
