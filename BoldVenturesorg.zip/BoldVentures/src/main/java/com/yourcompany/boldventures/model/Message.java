package com.yourcompany.boldventures.model;



import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "messages")
public class Message {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	@Column
    private Long senderUserId;
	@Column
    private Long receiverUserId;
	@Column
    private String content;
	@Column
    private LocalDateTime timestamp;
    // Getters and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSenderUserId() {
		return senderUserId;
	}
	public void setSenderUserId(Long senderUserId) {
		this.senderUserId = senderUserId;
	}
	public Long getReceiverUserId() {
		return receiverUserId;
	}
	public void setReceiverUserId(Long receiverUserId) {
		this.receiverUserId = receiverUserId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	public Message(Long id, Long senderUserId, Long receiverUserId, String content, LocalDateTime timestamp) {
		super();
		this.id = id;
		this.senderUserId = senderUserId;
		this.receiverUserId = receiverUserId;
		this.content = content;
		this.timestamp = timestamp;
	}
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
