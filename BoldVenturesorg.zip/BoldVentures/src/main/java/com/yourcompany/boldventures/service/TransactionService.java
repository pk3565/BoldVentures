package com.yourcompany.boldventures.service;

import java.util.List;

import com.yourcompany.boldventures.model.Transaction;

public class TransactionService {

	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	public Transaction getTransactionById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Transaction createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		return null;
	}

	public Transaction updateTransaction(Long id, Transaction transaction) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean deleteTransaction(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

}
