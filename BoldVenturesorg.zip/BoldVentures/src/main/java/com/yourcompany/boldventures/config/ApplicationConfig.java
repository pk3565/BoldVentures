package com.yourcompany.boldventures.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.yourcompany.boldventures.service.MyService;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = {"com.yourcompany.boldventures"})
public class ApplicationConfig implements WebMvcConfigurer {

    // Define beans or configuration methods here
    
    // Example bean definition
    @Bean
    MyService myService() {
        return new MyService();
	}
}