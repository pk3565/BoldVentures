package com.yourcompany.boldventures.exception.handler;



@SuppressWarnings("serial")
public class CustomException extends RuntimeException {

    public CustomException(String message) {
        super(message);
    }
}
