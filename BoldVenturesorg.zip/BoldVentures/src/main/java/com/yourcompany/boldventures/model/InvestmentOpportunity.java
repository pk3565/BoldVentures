package com.yourcompany.boldventures.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "investmentsoppurtunities")
public class InvestmentOpportunity {
	@Column
	private String name;
	@Column
    private String description;
	@Column
    private double investmentAmount;
	public InvestmentOpportunity(String name, String description, double investmentAmount) {
		super();
		this.name = name;
		this.description = description;
		this.investmentAmount = investmentAmount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getInvestmentAmount() {
		return investmentAmount;
	}
	public void setInvestmentAmount(double investmentAmount) {
		this.investmentAmount = investmentAmount;
	}
	public InvestmentOpportunity() {
		super();
		// TODO Auto-generated constructor stub
	}
	

    
}
