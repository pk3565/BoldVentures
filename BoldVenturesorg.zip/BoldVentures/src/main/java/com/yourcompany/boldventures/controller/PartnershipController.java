package com.yourcompany.boldventures.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yourcompany.boldventures.model.Partnership;
import com.yourcompany.boldventures.service.PartnershipService;

@RestController
@RequestMapping("/partnerships")
public class PartnershipController {

    @Autowired
    private PartnershipService partnershipService;

    @GetMapping("/getAll")
    public ResponseEntity<List<Partnership>> getAllPartnerships() {
        List<Partnership> partnerships = partnershipService.getAllPartnerships();
        return new ResponseEntity<>(partnerships, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Partnership> getPartnershipById(@PathVariable Long id) {
        Partnership partnership = partnershipService.getPartnershipById(id);
        if (partnership != null) {
            return new ResponseEntity<>(partnership, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<Partnership> createPartnership(@RequestBody Partnership partnership) {
        Partnership createdPartnership = partnershipService.createPartnership(partnership);
        return new ResponseEntity<>(createdPartnership, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Partnership> updatePartnership(@PathVariable Long id, @RequestBody Partnership partnership) {
        Partnership updatedPartnership = partnershipService.updatePartnership(id, partnership);
        if (updatedPartnership != null) {
            return new ResponseEntity<>(updatedPartnership, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePartnership(@PathVariable Long id) {
        boolean deleted = partnershipService.deletePartnership(id);
        if (deleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
