package com.yourcompany.boldventures.dao;

import com.yourcompany.boldventures.model.Investment;

public interface InvestmentDAO {
    void saveInvestment(Investment investment);
    Investment getInvestmentById(Long id);
    void updateInvestment(Investment investment);
    void deleteInvestment(Long id);
    // Other methods as needed
}
