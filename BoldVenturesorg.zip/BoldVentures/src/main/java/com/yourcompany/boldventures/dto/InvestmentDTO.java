package com.yourcompany.boldventures.dto;



public class InvestmentDTO {
    private Long id;
    private Long senderUserId;
    private Long receiverUserId;
    private double amount;
    private String equityOffered;
    private String terms;
    private String status;
    // Other relevant fields, getters, and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSenderUserId() {
		return senderUserId;
	}
	public void setSenderUserId(Long senderUserId) {
		this.senderUserId = senderUserId;
	}
	public Long getReceiverUserId() {
		return receiverUserId;
	}
	public void setReceiverUserId(Long receiverUserId) {
		this.receiverUserId = receiverUserId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getEquityOffered() {
		return equityOffered;
	}
	public void setEquityOffered(String equityOffered) {
		this.equityOffered = equityOffered;
	}
	public String getTerms() {
		return terms;
	}
	public void setTerms(String terms) {
		this.terms = terms;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
}

