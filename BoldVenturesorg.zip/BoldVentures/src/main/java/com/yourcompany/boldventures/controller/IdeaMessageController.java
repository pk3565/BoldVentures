package com.yourcompany.boldventures.controller;


import com.yourcompany.boldventures.model.IdeaMessage;
import com.yourcompany.boldventures.repository.IdeaMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IdeaMessageController {

    @Autowired
    private IdeaMessageRepository ideaMessageRepository;

    @PostMapping("/ideas")
    public ResponseEntity<String> submitIdeaMessage(@RequestBody IdeaMessage ideaMessage) {
        ideaMessageRepository.save(ideaMessage);
        return new ResponseEntity<>("Your idea has been successfully submitted! Thank you for sharing.", HttpStatus.CREATED);
    }
}

