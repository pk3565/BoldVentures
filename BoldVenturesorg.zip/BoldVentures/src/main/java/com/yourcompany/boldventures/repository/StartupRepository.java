package com.yourcompany.boldventures.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.yourcompany.boldventures.model.Startup;

public interface StartupRepository extends JpaRepository<Startup, Long> {
    
    List<Startup> findByStatus(String status);
    
    
    List<Startup> findByIndustry(String industry);
    
    
    List<Startup> findByFounderName(String founderName);
    
    
    @Query("SELECT s FROM Startup s WHERE s.fundingAmount > :amount")
    List<Startup> findByFundingAmountGreaterThan(double amount);
}
