package com.yourcompany.boldventures.model;



import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "tranactionAmount")
public class Transaction {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	@Column
    private Long senderUserId;
	@Column
    private Long receiverUserId;
	@Column
    private double amount;
	@Column
    private String type; // e.g., "Funding", "Equity Transfer", etc.
	@Column
    private LocalDateTime timestamp;
    // Getters and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSenderUserId() {
		return senderUserId;
	}
	public void setSenderUserId(Long senderUserId) {
		this.senderUserId = senderUserId;
	}
	public Long getReceiverUserId() {
		return receiverUserId;
	}
	public void setReceiverUserId(Long receiverUserId) {
		this.receiverUserId = receiverUserId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	public Transaction(Long id, Long senderUserId, Long receiverUserId, double amount, String type,
			LocalDateTime timestamp) {
		super();
		this.id = id;
		this.senderUserId = senderUserId;
		this.receiverUserId = receiverUserId;
		this.amount = amount;
		this.type = type;
		this.timestamp = timestamp;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
