package com.yourcompany.boldventures.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "upcomingBusinesses")
public class Startup {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	@Column
    private String name;
	@Column
    private String description;
	@Column
    private String industry;
	@Column
    private String location;
	@Column
    private String fundingRequirement;
   
	// Getters and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getFundingRequirement() {
		return fundingRequirement;
	}
	public void setFundingRequirement(String fundingRequirement) {
		this.fundingRequirement = fundingRequirement;
	}
	public Startup(Long id, String name, String description, String industry, String location,
			String fundingRequirement) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.industry = industry;
		this.location = location;
		this.fundingRequirement = fundingRequirement;
	}
	public Startup() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
