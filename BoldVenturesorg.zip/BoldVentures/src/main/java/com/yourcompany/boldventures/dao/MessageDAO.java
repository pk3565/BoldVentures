package com.yourcompany.boldventures.dao;

import com.yourcompany.boldventures.model.Message;

public interface MessageDAO {
    void saveMessage(Message message);
    Message getMessageById(Long id);
    void updateMessage(Message message);
    void deleteMessage(Long id);
    // Other methods as needed
}
