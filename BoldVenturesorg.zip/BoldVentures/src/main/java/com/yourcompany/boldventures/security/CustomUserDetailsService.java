package com.yourcompany.boldventures.security;

import java.util.List;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface CustomUserDetailsService extends UserDetailsService {
    
	User findUserByEmail(String email);
    List<User> findUsersByRole(String role);
    User registerUser(User user);
    void updateUser(User user);
    void deleteUser(Long userId);
    void resetPassword(String email, String newPassword);
}