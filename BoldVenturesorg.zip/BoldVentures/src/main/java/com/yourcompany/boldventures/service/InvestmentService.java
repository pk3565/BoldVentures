package com.yourcompany.boldventures.service;

import java.util.List;

import com.yourcompany.boldventures.model.Investment;

public class InvestmentService {

	public List<Investment> getAllInvestments() {
		// TODO Auto-generated method stub
		return null;
	}

	public Investment getInvestmentById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Investment createInvestment(Investment investment) {
		// TODO Auto-generated method stub
		return null;
	}

	public Investment updateInvestment(Long id, Investment investment) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean deleteInvestment(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

}
