package com.yourcompany.boldventures.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yourcompany.boldventures.model.User;
import com.yourcompany.boldventures.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void registerUser(User user) {
        // Perform validation or additional logic before saving the user
        // Example: Check if the username or email is already in use
        // Save the user
        userRepository.save(user);
    }

    public User authenticateUser(String username, String password) {
        // Retrieve the user by username from the repository
        User user = userRepository.findByUsername(username);
        // Perform authentication logic (e.g., comparing passwords)
        if (user != null && user.getPassword().equals(password)) {
            return user;
        } else {
            return null;
        }
    }

    public User getUserById(Long userId) {
        // Retrieve the user by ID from the repository
        return userRepository.findById(userId).orElse(null);
    }

    // Additional methods for updating user profile, password, etc.
}
