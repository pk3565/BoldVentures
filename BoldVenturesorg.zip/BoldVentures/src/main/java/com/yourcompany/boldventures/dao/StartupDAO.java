package com.yourcompany.boldventures.dao;

import com.yourcompany.boldventures.model.Startup;

public interface StartupDAO {
    void saveStartup(Startup startup);
    Startup getStartupById(Long id);
    void updateStartup(Startup startup);
    void deleteStartup(Long id);
    // Other methods as needed
    
}
