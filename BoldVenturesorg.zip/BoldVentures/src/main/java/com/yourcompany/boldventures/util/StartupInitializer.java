package com.yourcompany.boldventures.util;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@Component
public class StartupInitializer {

    private static final Logger logger = LoggerFactory.getLogger(StartupInitializer.class);

    @PostConstruct
    public void init() {
        logger.info("Application started successfully");
        // Initialization logic
    }

    @PreDestroy
    public void cleanup() {
        logger.info("Application shutting down");
        // Cleanup logic
    }
}
