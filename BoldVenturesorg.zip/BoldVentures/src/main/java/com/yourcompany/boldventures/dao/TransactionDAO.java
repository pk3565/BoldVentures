package com.yourcompany.boldventures.dao;

import com.yourcompany.boldventures.model.Transaction;

public interface TransactionDAO {
    void saveTransaction(Transaction transaction);
    Transaction getTransactionById(Long id);
    void updateTransaction(Transaction transaction);
    void deleteTransaction(Long id);
    // Other methods as needed
}
