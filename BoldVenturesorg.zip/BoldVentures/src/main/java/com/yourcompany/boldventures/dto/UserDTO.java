package com.yourcompany.boldventures.dto;


public class UserDTO {
    private Long id;
    private String username;
    private String email;
    private String password;
    private String startupName;
    private String industry;
    private String location;
    private String fundingRequirement;
    // Other relevant fields, getters, and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStartupName() {
		return startupName;
	}
	public void setStartupName(String startupName) {
		this.startupName = startupName;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getFundingRequirement() {
		return fundingRequirement;
	}
	public void setFundingRequirement(String fundingRequirement) {
		this.fundingRequirement = fundingRequirement;
	}
    
}
