package com.yourcompany.boldventures.dao;

import com.yourcompany.boldventures.model.Investor;

public interface InvestorDAO {
    void saveInvestor(Investor investor);
    Investor getInvestorById(Long id);
    void updateInvestor(Investor investor);
    void deleteInvestor(Long id);
    // Other methods as needed
}
