package com.yourcompany.boldventures.dto;



public class InvestorDTO {
    private Long id;
    private String investorName;
    private String investmentPreferences;
    private String industriesOfInterest;
    private String investmentAmountRange;
    // Other relevant fields, getters, and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getInvestorName() {
		return investorName;
	}
	public void setInvestorName(String investorName) {
		this.investorName = investorName;
	}
	public String getInvestmentPreferences() {
		return investmentPreferences;
	}
	public void setInvestmentPreferences(String investmentPreferences) {
		this.investmentPreferences = investmentPreferences;
	}
	public String getIndustriesOfInterest() {
		return industriesOfInterest;
	}
	public void setIndustriesOfInterest(String industriesOfInterest) {
		this.industriesOfInterest = industriesOfInterest;
	}
	public String getInvestmentAmountRange() {
		return investmentAmountRange;
	}
	public void setInvestmentAmountRange(String investmentAmountRange) {
		this.investmentAmountRange = investmentAmountRange;
	}
    
}
