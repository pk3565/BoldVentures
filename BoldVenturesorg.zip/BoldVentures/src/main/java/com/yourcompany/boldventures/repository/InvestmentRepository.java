package com.yourcompany.boldventures.repository;




import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yourcompany.boldventures.model.Investment;

public interface InvestmentRepository extends JpaRepository<Investment, Long> {
    // Additional custom query methods can be added here if needed
	 List<Investment> findBySenderUserId(Long senderUserId);
	 List<Investment> findByReceiverUserId(Long receiverUserId);

}
