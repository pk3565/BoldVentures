package com.yourcompany.boldventures.dao;

import com.yourcompany.boldventures.model.Partnership;

public interface PartnershipDAO {
    void savePartnership(Partnership partnership);
    Partnership getPartnershipById(Long id);
    void updatePartnership(Partnership partnership);
    void deletePartnership(Long id);
    // Other methods as needed
}
