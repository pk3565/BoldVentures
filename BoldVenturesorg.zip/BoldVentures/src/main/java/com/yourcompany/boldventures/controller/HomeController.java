package com.yourcompany.boldventures.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/home")
    public String home(Model model) {
        // Add any necessary data to the model
        model.addAttribute("pageTitle", "BoldVentures - Empowering Tomorrow's Innovators");
        model.addAttribute( "Welcome to Bold Ventures");
        return "pk.html";
    }
    
}
