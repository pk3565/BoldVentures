package com.yourcompany.boldventures.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yourcompany.boldventures.model.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    // Additional custom query methods can be added here if needed
	List<Notification> findByRecipient(String recipient);
}
