package com.yourcompany.boldventures.dao;

import com.yourcompany.boldventures.model.Notification;

public interface NotificationDAO {
    void saveNotification(Notification notification);
    Notification getNotificationById(Long id);
    void updateNotification(Notification notification);
    void deleteNotification(Long id);
    // Other methods as needed
}
