package com.yourcompany.boldventures.model;



import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Notification {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	@Column
    private Long recipientUserId;
	@Column
    private String content;
	@Column
    private LocalDateTime timestamp;
	@Column
    private String message;
    // Getters and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getRecipientUserId() {
		return recipientUserId;
	}
	public void setRecipientUserId(Long recipientUserId) {
		this.recipientUserId = recipientUserId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	public String getMessage() {
		
		return message;
	}
	public void getMessage(String content, String message) {
		this.message = message;
	}
	public Notification(Long id, Long recipientUserId, String content, LocalDateTime timestamp, String message) {
		super();
		this.id = id;
		this.recipientUserId = recipientUserId;
		this.content = content;
		this.timestamp = timestamp;
		this.message = message;
	}
	public Notification() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
