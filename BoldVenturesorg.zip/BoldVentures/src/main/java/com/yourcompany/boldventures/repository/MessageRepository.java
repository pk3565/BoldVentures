package com.yourcompany.boldventures.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yourcompany.boldventures.model.Message;

public interface MessageRepository extends JpaRepository<Message, Long> {
    // Additional custom query methods can be added here if needed
	List<Message> findBySenderUserId(Long senderUserId);
	
}
