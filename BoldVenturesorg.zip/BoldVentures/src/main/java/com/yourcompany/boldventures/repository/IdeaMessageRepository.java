package com.yourcompany.boldventures.repository;


import com.yourcompany.boldventures.model.IdeaMessage;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IdeaMessageRepository extends JpaRepository<IdeaMessage, Long> {
	List<IdeaMessage> findBySenderUserId(Long senderUserId);


}
