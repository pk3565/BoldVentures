package com.yourcompany.boldventures.repository;




import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.boldventures.model.Investor;
@Repository
public interface InvestorRepository extends JpaRepository<Investor, Long> {
    // Additional custom query methods can be added here if needed
	List<Investor> findByName(String name);

}
