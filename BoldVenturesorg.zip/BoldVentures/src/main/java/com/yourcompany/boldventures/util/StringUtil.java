package com.yourcompany.boldventures.util;




	public class StringUtil {

	    /**
	     * Check if a string is null or empty.
	     * @param str The string to check.
	     * @return True if the string is null or empty, false otherwise.
	     */
	    public static boolean isNullOrEmpty(String str) {
	        return str == null || str.isEmpty();
	    }

	    /**
	     * Convert a string to title case (capitalize the first letter of each word).
	     * @param str The string to convert.
	     * @return The string in title case.
	     */
	    public static String toTitleCase(String str) {
	        if (isNullOrEmpty(str)) {
	            return str;
	        }

	        String[] words = str.split("\\s+");
	        StringBuilder result = new StringBuilder();

	        for (String word : words) {
	            result.append(word.substring(0, 1).toUpperCase())
	                  .append(word.substring(1).toLowerCase())
	                  .append(" ");
	        }

	        return result.toString().trim();
	    }
	}



