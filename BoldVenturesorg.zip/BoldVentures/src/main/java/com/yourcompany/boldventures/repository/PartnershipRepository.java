package com.yourcompany.boldventures.repository;




import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yourcompany.boldventures.model.Partnership;

public interface PartnershipRepository extends JpaRepository<Partnership, Long> {
    // Additional custom query methods can be added here if needed
	List<Partnership> findByStatus(String status);
}
