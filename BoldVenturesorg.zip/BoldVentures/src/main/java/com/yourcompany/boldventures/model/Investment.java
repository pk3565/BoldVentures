package com.yourcompany.boldventures.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "investments")
public class Investment {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	 @Column
    private Long senderUserId; // Investor
	 @Column
    private Long receiverUserId; // Startup
	 @Column
    private double amount;
	 @Column
    private String equityOffered;
	 @Column
    private String terms;
	 @Column
    private String status;
	 
	 @ManyToOne
	    @JoinColumn(name = "investor_id")
	    private Investor investor;
	 
	 @ManyToOne
	    @JoinColumn(name = "startup_id")
	    private Startup startup;
    
	// Getters and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSenderUserId() {
		return senderUserId;
	}
	public void setSenderUserId(Long senderUserId) {
		this.senderUserId = senderUserId;
	}
	public Long getReceiverUserId() {
		return receiverUserId;
	}
	public void setReceiverUserId(Long receiverUserId) {
		this.receiverUserId = receiverUserId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getEquityOffered() {
		return equityOffered;
	}
	public void setEquityOffered(String equityOffered) {
		this.equityOffered = equityOffered;
	}
	public String getTerms() {
		return terms;
	}
	public void setTerms(String terms) {
		this.terms = terms;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Investment(Long id, Long senderUserId, Long receiverUserId, double amount, String equityOffered,
			String terms, String status) {
		super();
		this.id = id;
		this.senderUserId = senderUserId;
		this.receiverUserId = receiverUserId;
		this.amount = amount;
		this.equityOffered = equityOffered;
		this.terms = terms;
		this.status = status;
	}
	public Investment(String string, int i) {
		return;
		// TODO Auto-generated constructor stub
	}
	
    
}
