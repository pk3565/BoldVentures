package com.yourcompany.boldventures;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoldVenturesApplicationTests {

	@Test
	void contextLoads() {
	}

}
