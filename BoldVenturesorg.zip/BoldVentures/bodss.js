function getUser() {
    const userId = document.getElementById("userId").value;

    fetch(`/api/users/${userId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(user => {
            displayUserInfo(user);
        })
        .catch(error => {
            console.error('Error:', error);
            displayUserInfo(null, `User not found for ID: ${userId}`);
        });
}

function displayUserInfo(user, errorMessage) {
    const userInfoContainer = document.getElementById("userInfo");
    userInfoContainer.innerHTML = "";

    if (errorMessage) {
        userInfoContainer.innerText = errorMessage;
    } else {
        const userDisplay = document.createElement("div");
        userDisplay.innerText = `User ID: ${user.id}, Name: ${user.name}, Email: ${user.email}`;
        userInfoContainer.appendChild(userDisplay);
    }
}
fetch('/investments')
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(investments => {
        // Handle the response (list of investments) here
        console.log(investments);
    })
    .catch(error => {
        console.error('Error:', error);
    });
    fetch('/investors')
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(investors => {
        // Handle the response (list of investors) here
        console.log(investors);
    })
    .catch(error => {
        console.error('Error:', error);
    });
    fetch('/messages')
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(messages => {
        // Handle the response (list of messages) here
        console.log(messages);
    })
    .catch(error => {
        console.error('Error:', error);
    });
    const notificationData = {
        // Your notification data here
    };
    
    fetch('/notifications', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(notificationData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(createdNotification => {
        // Handle the response (created notification) here
        console.log(createdNotification);
    })
    .catch(error => {
        console.error('Error:', error);
    });
    const partnershipData = {
        // Your partnership data here
    };
    
    fetch('/partnerships', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(partnershipData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(createdPartnership => {
        // Handle the response (created partnership) here
        console.log(createdPartnership);
    })
    .catch(error => {
        console.error('Error:', error);
    });
    const startupData = {
        // Your startup data here
    };
    
    fetch('/startups', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(startupData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(createdStartup => {
        // Handle the response (created startup) here
        console.log(createdStartup);
    })
    .catch(error => {
        console.error('Error:', error);
    });
    const transactionData = {
        // Your transaction data here
    };
    
    fetch('/transactions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(transactionData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(createdTransaction => {
        // Handle the response (created transaction) here
        console.log(createdTransaction);
    })
    .catch(error => {
        console.error('Error:', error);
    });
                